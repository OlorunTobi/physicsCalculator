See the project page online for more information:
http://code.google.com/p/jbox2d/

If you've downloaded this an archive, you should find the built java jars in the 'target' directories of each project.

jbox2d-library - this is the main physics library.

jbox2d-serialization - this adds serialization tools.  Requires google's protocol buffer library installed to fully build (http://code.google.com/p/protobuf/).

jbox2d-testbed - A simple framework for creating and running physics tests.